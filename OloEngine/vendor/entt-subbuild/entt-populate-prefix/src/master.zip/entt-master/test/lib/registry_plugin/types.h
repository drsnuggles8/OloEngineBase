#ifndef ENTT_LIB_REGISTRY_PLUGIN_TYPES_H
#define ENTT_LIB_REGISTRY_PLUGIN_TYPES_H

struct position {
    int x;
    int y;
};

struct velocity {
    double dx;
    double dy;
};

#endif
